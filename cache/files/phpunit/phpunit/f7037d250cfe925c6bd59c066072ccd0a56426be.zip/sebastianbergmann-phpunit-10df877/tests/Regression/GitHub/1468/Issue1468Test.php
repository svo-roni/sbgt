<?php
class Issue1468Test extends PHPUnit_Framework_TestCase
{
    /**
     * @todo Implement this test
     */
    public function testFailure()
    {
        $this->markTestIncomplete();
    }
}
