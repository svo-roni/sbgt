<?php
class ThrowNoExceptionTestCase extends PHPUnit_Framework_TestCase
{
    public function test()
    {
    }
}
